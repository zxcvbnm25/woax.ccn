<?php

/**
 * Template name: Zibll-链接列表
 * Description:   sidebar page
 */

// 获取链接列表
function zib_page_links()
{

    $type = 'card';
    $post_ID = get_queried_object_id();
    $args_orderby = get_post_meta($post_ID, 'page_links_orderby', true);
    $args_order = get_post_meta($post_ID, 'page_links_order', true);
    $args_limit = get_post_meta($post_ID, 'page_links_limit', true);
    $args_category = get_post_meta($post_ID, 'page_links_category', true);
    $args = array(
        'orderby'        => $args_orderby ? $args_orderby : 'name', //排序方式
        'order'          => $args_order ? $args_order : 'ASC', //升序还是降序
        'limit'          => $args_limit ? $args_limit : -1, //最多显示数量
        'category'       => $args_category, //以逗号分隔的类别ID列表
    );
    $links = get_bookmarks($args);

    $html = '';

    if ($links) {
        $html .= zib_links_box($links, $type, false);
    } elseif (is_super_admin()) {
        $html = '<a class="author-minicard links-card radius8" href="' . admin_url('link-manager.php') . '" target="_blank">添加链接</a>';
    } else {
        $html = '<div class="author-minicard links-card radius8">暂无链接，请联系管理员添加</div>';
    }
    return $html;
}

get_header();
$post_id = get_queried_object_id();
$header_style = zib_get_page_header_style();
$page_links_content_s = get_post_meta($post_id, 'page_links_content_s', true);
$page_links_content_position = get_post_meta($post_id, 'page_links_content_position', true);
$page_links_submit_s = get_post_meta($post_id, 'page_links_submit_s', true);
?>
<style>
.admin-btn{background: #8486f8;padding: 2px 10px;color: #fff;border-radius: 4px;}
.admin-guanli{visibility:hidden;position: absolute;min-width: 80px;background-color: var(--main-bg-color);padding: 10px 5px;z-index: 99;border-radius: var(--main-radius);box-shadow: 0 0 10px rgba(0,0,0,.1);right: -40px;margin-top: -40px;}
.xy_hide:hover>.admin-guanli{visibility:unset;}
.xy_hide:hover>.admin-btn{color: #fff;background: #6d6fd8;}
.f12{font-size:12px;}
.xypro_describe {position: relative;border: 1px dashed #dcdfe6;line-height: 26px;}
.xypro_describe_title {position: absolute;top: 0;left: 8px;-webkit-transform: translateY(-50%);transform: translateY(-50%);background: #fff;padding: 0 5px;color: #303133;font-weight: 500;max-width: 200px;white-space: nowrap;overflow: hidden;text-overflow: ellipsis;}
.xypro_describe_content{color: #606266;padding: 18px 15px 30px;}
.yq{width: 100%;max-width: 100%;table-layout: fixed;color: #909399;margin-bottom: 18px;border-top: 1px solid #ebeef5;border-left: 1px solid #ebeef5;}
.yq thead th {font-weight: 500;background: #ebeef5;text-align: center;padding: 8px;border-bottom: 1px solid #ebeef5;border-right: 1px solid #ebeef5;}
.yq_link td {text-align: center;padding: 8px;border-bottom: 1px solid #ebeef5;border-right: 1px solid #ebeef5;text-overflow: ellipsis;
    white-space: nowrap;overflow: hidden;}
.xy_li {text-align: center;font-size: 16px;line-height: 30px;}
.xy_li::marker {content: "#" counter(list-item) " ";color: var(--theme-color);}
.xy-mask {background-color: rgba(0,0,0,.5);}
.xy_height_hide{height: 300px;text-overflow: ellipsis;white-space: nowrap;overflow: hidden;}
.xy_height_hide_p{background: linear-gradient(180deg,hsla(0,0%,100%,0),#fff);width: 100%;z-index: 1;position: absolute;bottom: 0;margin: 0;height: 100px;}
.xy_height_hide_p2{text-align: center;bottom: 0;z-index: 2;position: absolute;left: 0;right: 0;cursor: pointer !important;}
.xy-more-btn{width: 20px;height: 20px;background-color: var(--main-bg-color);border: 1px solid rgb(237, 237, 237);border-radius: 50%;line-height: 18px;}

code{font-family: "lovely";}
.xy_callout ol li::marker {content: "#" counter(list-item) " ";color: var(--theme-color);}
.xy_callout {padding: 20px;border: 1px solid #e4e4e4;border-left-width: 5px;border-radius: 6px;line-height: 30px;font-weight: 600;border-left-color: var(--theme-color);}
.xy_content>h5{margin: 0;font-weight:600;font-size: 24px;line-height: 32px;padding:20px 0;text-align: center;}
.xy_checkbox:checked{background:var(--theme-color);-webkit-appearance: none;position: relative;border-radius: 2px;width: 15px;height: 15px;vertical-align: -2px;}
.xy_content h5:before {content: '「';color: var(--theme-color);font-weight: 600;margin-left: 5px;}
.xy_content h5:after {content: '」';color: var(--theme-color);font-weight: 600;margin-right: 5px;}
/**.xy_checkbox:checked:after {content:'';width: 6px;height: 10px;position: absolute;top: 1px;left: 5px;border: 2px solid #fff;border-top: 0;border-left: 0;-webkit-transform: rotate(45deg);transform: rotate(45deg);}**/
.wp-posts-content li{margin-bottom: 0;}
.xy-width{padding:0 30px 30px;}
.wp-posts-content ol>li>span{color: var(--theme-color);}
@media screen and (max-width:500px){.xy-width{padding:10px;}.wp-posts-content ol:not(.blocks-gallery-grid){margin:0;}.xy_hide{display:none;}.title-h-center{display:none;}.xy-mask {background-color: rgb(0 0 0 / 5%);}}
@media screen and (min-width:500px){.xy-width-190{width: 190px;}.xy-width-100{width: 100px;}}
</style>
<script>
$.getJSON("https://21lhz.cn/cdn/api/yiyanapi.php?encode=yulu",function(data){ $("#yulu").text(data.text);});$(function(){$("#yulu").click(function() {$(this).select();})})
</script>

<main class="container">
    <div class="content-wrap">
        <div class="content-layout">
            <div class="page-cover theme-box radius8 main-shadow">
                    <img class="fit-cover no-scale lazyloaded" src="<?php acgimg()?>" data-src="<?php acgimg()?>">
                    <div class="absolute xy-mask"></div>
                    <div class="list-inline box-body abs-center text-center">
                    <div class="title-h-center">
                        <span class="xy_content"><h5><font size="6" color="red"> 注</font>意提醒 </h5>
                            <li class="xy_li">开启外链重定向会判定失败</li>
                            <li class="xy_li">网站打开时间过长会请求失败</li>
                            <li class="xy_li">首页未有本站链接会判定失败</li>
                            <li class="xy_li">如有疑问可找博主咨询</li>
                        </span>
                    </div>
                    </div>
                </div>
            <?php while (have_posts()) : the_post(); ?>
                <?php echo zib_get_page_header(); ?>
                <?php echo Links(); ?>
                <?php
                /*if ($page_links_content_position != 'top') {
                    echo '<div class="zib-widget">' . zib_page_links() . '</div>';
                }*/
                echo'
               
                </div>';
                if ($page_links_content_s) {
                    echo '<div class="zib-widget"><article class="article wp-posts-content">';
                    the_content();
                    echo '</article>';
                    wp_link_pages(
                        array(
                            'before'           => '<p class="text-center post-nav-links radius8 padding-6">',
                            'after'            => '</p>',
                        )
                    );
                    echo '</div>';
                }
                /*if ($page_links_content_position == 'top') {
                    echo '<div class="zib-widget">' . zib_page_links() . '</div>';
                }*/
                if ($page_links_submit_s) {
                    $submit_args = array(
                        'title' => get_post_meta($post_id, 'page_links_submit_title', true),
                        'subtitle' => get_post_meta($post_id, 'page_links_submit_subtitle', true),
                        'dec' => get_post_meta($post_id, 'page_links_submit_dec', true)
                    );
                    echo zib_submit_links_card($submit_args);
                }
                ?>
                <?php ?>
            <?php endwhile; ?>
            <?php comments_template('/template/comments.php', true); ?>
        </div>
    </div>
    <?php get_sidebar(); ?>
</main>
<?php
get_footer();
