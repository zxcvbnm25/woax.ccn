
function xy_link(){
    global $wpdb;
    $links = $wpdb->prefix . 'links';
    $user_url = !empty($_REQUEST['user_url']) ? $_REQUEST['user_url'] : '';
    $xypro_url = esc_url(home_url());
    $url = 'https://v1.21lhz.cn/API/Links/api.php?user_url='.$user_url.'&url='.$xypro_url;
    //初始化
    $ch = curl_init();
    curl_setopt_array($ch, array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_MAXREDIRS => 2,
        CURLOPT_TIMEOUT => 3,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_HTTPHEADER => array(
            "Content-Type: application/x-www-form-urlencoded",
        ),
    ));
    $mes = curl_exec($ch);
    curl_close($ch); 
    
    $deta = date("Y-m-d H:i:s", time()+8*60*60);
    
    if($mes != '检测友情链接正常！'){
        $link_visible = 'N';
    }else{
        $link_visible = 'Y';
    }
    
    $msg = $mes == false ? '检测请求超时' : $mes;
    $link_con = array(
        'link_visible' => $link_visible,
        'link_updated' => $deta,
        'link_notes'   => $msg,
    );
    $wpdb->update($links,$link_con,array('link_url'=> $user_url));
    zib_send_json_success(array('code' => 0, 'msg' => $msg));
}
add_action('wp_ajax_xy_link', 'xy_link');

function xy_link_jc(){
    global $wpdb;
    $links = $wpdb->prefix . 'links';
    $deta = date("Y-m-d H:i:s", time()+8*60*60);
    $link_YN = !empty($_REQUEST['link_id']) ? $_REQUEST['link_id'] : '';
    $link_yn = mb_substr($link_YN, 0, 1, 'utf-8');
    $link_id = substr_replace($link_YN,"",0,1);
    
    if($link_yn == 'N'){
        $link_con = array(
            'link_visible' => 'N',
            'link_updated' => $deta,
            'link_notes'   => '请确认您已经添加本站的链接',
        );
        $wpdb->update($links,$link_con,array('link_id'=> $link_id));
        zib_send_json_success(array('code' => -1, 'msg' => '已将链接隐藏'));
    }elseif($link_yn == 'Y'){
        $link_con = array(
            'link_visible' => 'Y',
            'link_updated' => $deta,
            'link_notes'   => '检测友情链接正常！',
        );
        $wpdb->update($links,$link_con,array('link_id'=> $link_id));
        zib_send_json_success(array('code' => 0, 'msg' => '已将链接显示'));
    }elseif($link_yn == 'D'){
        $del = $wpdb->delete( $links, array( 'link_id' => $link_id ) );
        if($del){
            zib_send_json_success(array('code' => 0, 'msg' => '删除成功'));
        }
    }
}
add_action('wp_ajax_xy_link_jc', 'xy_link_jc');

function Links(){
    global $wpdb;
    $links = $wpdb->prefix . 'links';
    $links_count = $wpdb->get_var( "SELECT COUNT(`link_id`) FROM {$links}" );
    if(get_current_user_id() == 1){
        $gl = true;
        $gl_td = '<th align="center" class="xy-width-100 xy_hide">管理</th>';
    }
    $html = '
        <div class="zib-widget">
            <h3>友情链接检测

            </h3>
            <div class="xypro_describe"> 
                <p class="xy_height_hide_p2 xy_display_btn">查看更多友链 <i class="fa fa-angle-down ml6 xy-more-btn"></i></p>
                <p class="xy_height_hide_p"></p>
                <div class="xypro_describe_title">
                    检测列表（'.$links_count.'条友链）
                </div> 
                <div id="xy_hide" class="xypro_describe_content xy_height_hide">
                    <table class="yq">
                        <thead>
                            <tr>
                                <th align="center" class="xy-width-190">检测时间</th>
                                <th align="center">网站名称</th>
                                <th align="center">下链原因</th>
                                '.$gl_td.'
                            </tr>
                        </thead>';
    $html .= '          <tbody class="link-list">';
    
    //获取分页数据 :每页显示的数量 默认为50
    $limit = 15;
    $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
    //计算每一页第一条记录的显示偏移量
    //偏移量 = (页码 -1) \* 每页的显示数量
    $offset = ( $paged - 1 ) * $limit;
    
    $total = $wpdb->get_var( "SELECT COUNT(`link_id`) FROM $links" );
    $pages = ceil( $total / $limit );
    
    //调用
    $link = $wpdb->get_results("SELECT * FROM $links WHERE link_id ORDER BY link_id desc LIMIT {$limit} OFFSET {$offset}");
    
    foreach ($link as $k => $v){
        //$option = 'https://v1.21lhz.cn/API/Links/api.php?user_url='.$v->link_url.'&url='.$xypro_url;
        $name = $v->link_name;
        $btn = '<a href="javascript:;" class="but jb-pink testing" style="float:right;font-size:12px" id="'.$v->link_url.'">检测</a>';
        $btn = get_current_user_id() == 1 ? $btn : '';
        if($v->link_notes == '检测友情链接正常！'){
            $msg_btn = 'color: green;';
        }else{
            $msg_btn = 'color: red;';
        }
        if($gl){
            $gl_tr_td = '<td class="xy_hide">
            <a  href="javascript:;" class="admin-btn">管理</a>
            <ul class="admin-guanli">
                <li><a class="link_JC" href="javascript:;" id="Y'.$v->link_id.'">显示</a></li>
                <li><a class="link_JC" href="javascript:;" id="N'.$v->link_id.'">隐藏</a></li>
                <li><a class="link_JC" href="javascript:;" id="D'.$v->link_id.'">删除</a></li>
            </ul>
            </td>';
        }
        if($v->link_notes == '检测友情链接正常！'){
            $title = '检测友情链接正常';
            $name = '<a href="'.$v->link_url.'" target="_blank" data-toggle="tooltip" data-original-title="'.$v->link_description.'">'.$name.'</a>';
        }elseif($v->link_notes == '未获得URL相关数据，请重试！'){
            $title = '请检查网站是否开了重定向';
        }elseif($v->link_notes == '请确认您已经添加本站的链接'){
            $title = '请检查该链接是否做了本站友链';
        }elseif(!$v->link_notes){
            $title = '该网站站长还未检测';
        }else{
            $title = '检测网站访问时间过长';
        }
        $link_notes = $v->link_notes ? $v->link_notes : '该网站站长还未检测';
        $html .= '<tr class="yq_link">
                    <td>'.$v->link_updated.'</td>
                    <td>'.$name.'</td>
                    <td style="'.$msg_btn.'"><span data-toggle="tooltip" data-original-title="'.$title.'">'.$link_notes.'</span><span class="xy_hide">'.$btn.'</span></td>
                    '.$gl_tr_td.'
                </tr>';
    }
    
    $html .= '<script>
 
        var clicktype = true;
        $(".link_JC").on("click",function(e){
            if(confirm(\'是否进入下一步操作?\')) {
                if(clicktype == false){return false};
                clicktype = false;
                var link_id = $(this).attr("id");
                $.ajax({
                    type:"POST",
                    url:"'.admin_url('admin-ajax.php').'",
                    data:{
                        "action":"xy_link_jc",
                        "link_id":link_id,
                    },
                    cache:false,
                    dataType:"json",
                    success:function(data){
                        if(data.code == 0){
                            notyf(data.msg,"success");
                        }else{
                            notyf(data.msg,"warning");
                        }
                        clicktype = true;
                    },
                    error:function(data){
                        notyf("请求数据错误","warning");
                        clicktype = true;
                    }
                });
            }
        });
    </script>';
    
    $html .= '<script>
        var clicktype = true;
        $(".testing").on("click",function(e){
            if(clicktype == false){return false};
            clicktype = false;
            var link_url = $(this).attr("id");
            notyf("检测中请稍等...","load", "2");
            var text = "<i class=loading mr6></i> 检测中";
            $(this).attr("disabled",true);
            $(this).text("");
            $(this).append(text);
            $(this).addClass("jc-load");
            $.ajax({
                    type:"POST",
                    url:"'.admin_url('admin-ajax.php').'",
                    data:{
                        "action":"xy_link",
                        "user_url":link_url,
                    },
                    cache:false,
                    dataType:"json",
                    success:function(data){
                        if(data.code == 0){
                            notyf(data.msg,"success");
                        }else{
                            notyf(data.msg,"warning");
                        }
                        clicktype = true;
                        $(".jc-load").text("");
                        $(".jc-load").append("检测");
                        $(".jc-load").attr("disabled",false);
                        link_url.removeClass("jc-load");
                    },
                    error:function(data){
                        notyf("请求数据错误","warning");
                        clicktype = true;
                        $(".jc-load").text("");
                        $(".jc-load").append("检测");
                        $(".jc-load").attr("disabled",false);
                        link_url.removeClass("jc-load");
                    }
                });
        })
    </script>';
    
    $html .= '<script>
        $(document).on("click",".xy_display_btn",function(){
            $(".xy_display_btn").remove();
            $(".xy_height_hide_p").remove();
            $("#xy_hide").removeClass("xy_height_hide");
            $(".xypro_describe").append("<p class=\'xy_height_hide_p2 xy_hide_btn\'>隐藏友链列表 <i class=\'fa fa-angle-up ml6 xy-more-btn\'></i></p>");
        });
        $(document).on("click",".xy_hide_btn",function(){
            $(".xy_hide_btn").remove();
            $("#xy_hide").addClass("xy_height_hide");
            $(".xypro_describe").append("<p class=\'xy_height_hide_p2 xy_display_btn\'>查看更多友链 <i class=\'fa fa-angle-down ml6 xy-more-btn\'></i></p><p class=\'xy_height_hide_p\'></p>");
            $("body,html").animate({scrollTop:$(".xypro_describe").offset().top},400);

        });
    </script>';
    $html .= '</tbody></table>';
    $html .= $link ? xy_pages($pages,$paged) : '<div class="text-center ajax-item "><img style="width:280px;opacity: .7;" src="https://demo.21lhz.cn/wp-content/themes/zibll/img/null.svg"><p style="" class="em09 muted-3-color separator">暂无友链链接</p></div>';
    $html .= '</div></div></div>';
    return $html;
}
/**
* 数字分页函数
* 因为wordpress默认仅仅提供简单分页
* 所以要实现数字分页，需要自定义函数      
*/
function xy_pages($max_page,$paged) {
    $html = '';
    $html.= '<style>
        .pagination{margin:30px 0;padding:0 10px;text-align:center;font-size:12px;display:block;border-radius:0}
        .excerpts .pagination{margin-bottom: 10px;}
        .pagination ul{display:inline-block !important;margin-left:0;margin-bottom:0;padding:0}
        .pagination ul > li{display:inline}
        .pagination ul > li > a,.pagination ul > li > span{margin:0 2px;padding:6px 12px;background-color:#ddd;color:#666;border-radius:2px;opacity:.88}
        .pagination ul > li > a:hover,.pagination ul > li > a:focus{opacity:1}
        .pagination ul > .active > a,.pagination ul > .active > span{background-color:#1d1d1d;color:#fff}
        .pagination ul > .active > a,.pagination ul > .active > span{cursor:default}
        .pagination ul > li > span,.pagination ul > .disabled > span,.pagination ul > .disabled > a,.pagination ul > .disabled > a:hover,.pagination ul > .disabled > a:focus{color:#999999;background-color:transparent;cursor:default}
    </style>';
    
    $p = 2;
    if ( $max_page == 1 ) {
        return;
    }
    $html.= '<span class="pagination"><ul>';
    $paged = !empty( $paged ) ? $paged : 1;
    
    if ( $paged > 1 ) {
        $html.= '<li><a href="'.esc_html( get_pagenum_link( 1 ) ).'">首页</a></li>';
    }
    
    $html.= '<li class="prev-page">';
    $html.= '</li>';
    for ( $i = $paged - $p; $i <= $paged + $p; $i++ ) {
        if ( $i > 0 && $i <= $max_page ) {
            if($i == $paged){
                $html.= "<li class=\"active\"><span>{$i}</span></li>";
            }else{
                $html.= '<li><a href="'.esc_html( get_pagenum_link( $i ) ).'">'. $i .'</a></li>';
            }
        }
    }
    $html.= '<li class="next-page">';
    $html.= '</li>';
    $html.= '<li><a href="'.esc_html( get_pagenum_link( $max_page ) ).'">尾页</a></li>';
    //$html.= '<li><span>共 '.$max_page.' 页</span></li>';
    $html.= '</ul></span>';
    return $html;
}

//随机图片
function acgimg(){
    $rand=rand(0,2);
    if($rand =='0'){
        echo 'https://21lhz.cn/cdn/api/roll.php?imgurl=tp';
    }elseif($rand =='1'){
        echo 'https://api.21lhz.cn/xypro/api-acg.php';
    }else{
         echo 'https://kpi.21lhz.cn/images/acg/acg-api.php?api=acg-picture';
    }
}